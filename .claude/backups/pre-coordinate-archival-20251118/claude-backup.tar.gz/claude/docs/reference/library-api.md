# Library API Reference

Quick lookup reference for all `.claude/lib/` utility libraries. This document provides function signatures, return formats, and usage examples for reusable Bash libraries.

## Purpose

Utility libraries provide reusable functions for common tasks across commands and agents. Use this reference when:
- You need to call a specific utility function in a command
- You want to understand the API of an existing library
- You're looking for existing utilities before implementing new logic

For task-focused guides on when and how to use libraries, see [Using Utility Libraries](../guides/using-utility-libraries.md).

## Quick Index

**Core Utilities**:
- [unified-location-detection.sh](#unified-location-detectionsh) - Standardized location detection for workflow commands
- [plan-core-bundle.sh](#plan-core-bundlesh) - Plan parsing and manipulation
- [metadata-extraction.sh](#metadata-extractionsh) - Metadata extraction from reports/plans
- [checkpoint-utils.sh](#checkpoint-utilssh) - Checkpoint-based state management
- [state-persistence.sh](#state-persistencesh) - GitHub Actions-style selective state persistence

**Agent Support**:
- [agent-registry-utils.sh](#agent-registry-utilssh) - Agent registration and discovery
- [hierarchical-agent-support.sh](#hierarchical-agent-supportsh) - Multi-level agent coordination

**Workflow Support**:
- [unified-logger.sh](#unified-loggersh) - Structured logging with rotation
- [error-handling.sh](#error-handlingsh) - Standardized error handling patterns
- [context-pruning.sh](#context-pruningsh) - Context window optimization
- [overview-synthesis.sh](#overview-synthesissh) - Standardized overview synthesis decision logic

**Analysis and Validation**:
- [complexity-thresholds.sh](#complexity-thresholdssh) - Complexity scoring for plans
- [structure-validator.sh](#structure-validatorsh) - Directory structure validation

See [Complete Library List](#complete-library-list) for all 70+ libraries.

---

## Core Utilities

### unified-location-detection.sh

Standardized location detection for all workflow commands. Replaces command-specific location logic with a single, tested library.

**Performance**: <1s execution, <11k tokens (vs 75.6k baseline for agent-based detection)

**Commands using this library**: `/supervise`, `/orchestrate`, `/report`, `/research`, `/plan`

#### Core Functions

##### `perform_location_detection(workflow_description, [force_new_topic])`

Complete location detection workflow. Orchestrates all detection functions and returns JSON with topic paths.

**Arguments**:
- `workflow_description` (string): User-provided workflow description
- `force_new_topic` (optional, default: `"false"`): Set to `"true"` to skip existing topic reuse check

**Returns**: JSON object with location context:
```json
{
  "topic_number": "082",
  "topic_name": "auth_patterns_research",
  "topic_path": "/path/to/specs/082_auth_patterns_research",
  "artifact_paths": {
    "reports": "/path/to/specs/082_auth_patterns_research/reports",
    "plans": "/path/to/specs/082_auth_patterns_research/plans",
    "summaries": "/path/to/specs/082_auth_patterns_research/summaries",
    "debug": "/path/to/specs/082_auth_patterns_research/debug",
    "scripts": "/path/to/specs/082_auth_patterns_research/scripts",
    "outputs": "/path/to/specs/082_auth_patterns_research/outputs"
  }
}
```

**Exit Codes**:
- `0`: Success
- `1`: Failure (directory creation or detection failed)

**Usage Example**:
```bash
# Source the library
source "${CLAUDE_CONFIG}/.claude/lib/unified-location-detection.sh"

# Perform location detection
LOCATION_JSON=$(perform_location_detection "research authentication patterns")

# Extract paths using jq
if command -v jq &>/dev/null; then
  TOPIC_PATH=$(echo "$LOCATION_JSON" | jq -r '.topic_path')
  REPORTS_DIR=$(echo "$LOCATION_JSON" | jq -r '.artifact_paths.reports')
else
  # Fallback without jq (sed parsing)
  TOPIC_PATH=$(echo "$LOCATION_JSON" | grep -o '"topic_path": *"[^"]*"' | sed 's/.*: *"\([^"]*\)".*/\1/')
  REPORTS_DIR=$(echo "$LOCATION_JSON" | grep -o '"reports": *"[^"]*"' | sed 's/.*: *"\([^"]*\)".*/\1/')
fi

# MANDATORY VERIFICATION checkpoint
if [ ! -d "$TOPIC_PATH" ]; then
  echo "ERROR: Location detection failed - directory not created"
  exit 1
fi

# Use the paths
echo "Creating report in: $REPORTS_DIR"
```

##### `detect_project_root()`

Determine project root directory with git worktree support.

**Arguments**: None

**Returns**: Absolute path to project root (printed to stdout)

**Precedence**:
1. `CLAUDE_PROJECT_DIR` environment variable (manual override)
2. Git repository root (via `git rev-parse --show-toplevel`)
3. Current working directory (fallback)

**Exit Codes**: `0` (always succeeds, uses fallback if needed)

**Usage Example**:
```bash
PROJECT_ROOT=$(detect_project_root)
echo "Project root: $PROJECT_ROOT"
```

##### `sanitize_topic_name(raw_name)`

Convert workflow description to valid topic directory name.

**Arguments**:
- `raw_name` (string): Raw workflow description (user input)

**Returns**: Sanitized topic name (snake_case, max 50 chars)

**Sanitization Rules**:
- Convert to lowercase
- Replace spaces with underscores
- Remove all non-alphanumeric characters except underscores
- Trim leading/trailing underscores
- Collapse multiple consecutive underscores
- Truncate to 50 characters

**Exit Codes**: `0` (always succeeds)

**Usage Example**:
```bash
TOPIC_NAME=$(sanitize_topic_name "Research: Authentication Patterns")
# Result: "research_authentication_patterns"

TOPIC_NAME=$(sanitize_topic_name "OAuth 2.0 Security (Best Practices)")
# Result: "oauth_20_security_best_practices"
```

##### `ensure_artifact_directory(file_path)`

Creates parent directory for artifact file using lazy creation pattern.

**Arguments**:
- `file_path` (string): Absolute path to artifact file (e.g., report, plan, summary)

**Returns**: Nothing (exits on failure)

**Creates**:
- Parent directory only if it doesn't exist

**Exit Codes**:
- `0`: Success (directory exists or was created)
- `1`: Failure (directory creation failed)

**Behavior**:
- **Idempotent**: Safe to call multiple times for the same path
- **Lazy**: Creates directories only when files are actually written
- **Minimal overhead**: <5ms per call, directory check + mkdir if needed

**Performance**: Eliminates 400-500 empty directories by creating directories on-demand instead of eagerly.

**Usage Example**:
```bash
# Before writing any file, ensure parent directory exists
REPORT_PATH="${TOPIC_DIR}/reports/001_analysis.md"
ensure_artifact_directory "$REPORT_PATH" || {
  echo "ERROR: Failed to create parent directory"
  exit 1
}

# Now safe to write file
echo "content" > "$REPORT_PATH"
```

**Common Patterns**:
```bash
# In commands
ensure_artifact_directory "$PLAN_PATH" || exit 1
cat > "$PLAN_PATH" <<EOF
...
EOF

# In agent templates (via Bash tool)
source .claude/lib/unified-location-detection.sh
ensure_artifact_directory "$REPORT_PATH" || {
  echo "ERROR: Failed to create directory" >&2
  exit 1
}
```

##### `create_topic_structure(topic_path)`

Create topic root directory using lazy subdirectory creation.

**Arguments**:
- `topic_path` (string): Absolute path to topic directory

**Returns**: Nothing (exits on failure)

**Creates**:
- Topic root directory ONLY
- Subdirectories (reports/, plans/, etc.) created on-demand via `ensure_artifact_directory()`

**Exit Codes**:
- `0`: Success (topic root created)
- `1`: Failure (directory creation failed)

**Behavior**: Creates only the topic root directory. Subdirectories are created on-demand when files are written to them.

**Usage Example**:
```bash
TOPIC_PATH="/path/to/specs/082_auth_patterns"
create_topic_structure "$TOPIC_PATH" || {
  echo "ERROR: Failed to create topic structure"
  exit 1
}

# Only topic root exists at this point
# Subdirectories created when files are written using ensure_artifact_directory()
```

##### `create_research_subdirectory(topic_path, research_name)`

Create numbered subdirectory within topic's `reports/` directory for hierarchical research (/research command).

**Arguments**:
- `topic_path` (string): Absolute path to topic directory
- `research_name` (string): Sanitized snake_case name for research subdirectory

**Returns**: Absolute path to research subdirectory (printed to stdout)

**Creates**: `{topic_path}/reports/{NNN_research_name}/` where NNN is next sequential number

**Exit Codes**:
- `0`: Success
- `1`: Error (invalid arguments, directory creation failed)

**Usage Example**:
```bash
TOPIC_PATH="/path/to/specs/082_auth_patterns"
RESEARCH_SUBDIR=$(create_research_subdirectory "$TOPIC_PATH" "oauth_analysis")
# Result: /path/to/specs/082_auth_patterns/reports/001_oauth_analysis/

# Second research in same topic
RESEARCH_SUBDIR=$(create_research_subdirectory "$TOPIC_PATH" "jwt_patterns")
# Result: /path/to/specs/082_auth_patterns/reports/002_jwt_patterns/
```

#### Supporting Functions

##### `detect_specs_directory(project_root)`

Determine specs directory location (`.claude/specs` vs `specs`).

**Arguments**:
- `project_root` (string): Absolute path to project root

**Returns**: Absolute path to specs directory

**Precedence**:
1. `.claude/specs` (preferred, modern convention)
2. `specs` (legacy convention)
3. Create `.claude/specs` (default for new projects)

**Exit Codes**:
- `0`: Success
- `1`: Failed to create directory

##### `get_next_topic_number(specs_root)`

Calculate next sequential topic number from existing topics.

**Arguments**:
- `specs_root` (string): Absolute path to specs directory

**Returns**: Three-digit topic number (e.g., "001", "042", "137")

**Logic**: Find max existing topic number, increment by 1

**Exit Codes**: `0` (always succeeds)

##### `find_existing_topic(specs_root, topic_name_pattern)`

Search for existing topic matching name pattern (optional reuse).

**Arguments**:
- `specs_root` (string): Absolute path to specs directory
- `topic_name_pattern` (string): Regex pattern to match topic names

**Returns**: Topic number if found, empty string if not found

**Exit Codes**: `0` (always succeeds, whether found or not)

---

### plan-core-bundle.sh

Plan parsing, manipulation, and metadata extraction. Used by `/plan`, `/implement`, `/expand`, `/collapse`, and `/revise` commands.

**Performance**: Pure bash, no AI calls, <1s parsing for typical plans

#### Core Functions

##### `parse_plan_file(plan_path)`

Parse plan structure and extract phases.

**Arguments**:
- `plan_path` (string): Absolute path to plan file

**Returns**: Plan metadata (phases, tasks, complexity)

**Exit Codes**:
- `0`: Success
- `1`: Failure (file not found, invalid format)

##### `extract_phase_info(plan_path, phase_number)`

Extract phase details and tasks from plan.

**Arguments**:
- `plan_path` (string): Absolute path to plan file
- `phase_number` (integer): Phase number to extract

**Returns**: Phase metadata (name, tasks, dependencies)

**Exit Codes**:
- `0`: Success
- `1`: Failure (phase not found, invalid format)

##### `get_plan_metadata(plan_path)`

Get plan-level metadata (complexity, time estimates, dependencies).

**Arguments**:
- `plan_path` (string): Absolute path to plan file

**Returns**: Plan metadata in key-value format

**Exit Codes**:
- `0`: Success
- `1`: Failure (file not found, invalid format)

---

### metadata-extraction.sh

Metadata extraction from reports and plans for context window optimization. Enables 99% context reduction for hierarchical agent patterns.

**Performance**: <100ms extraction, 5000 tokens → 50 tokens typical reduction

#### Core Functions

##### `extract_report_metadata(report_path)`

Extract title, summary, file paths, and recommendations from research reports.

**Arguments**:
- `report_path` (string): Absolute path to report file

**Returns**: JSON object with metadata:
```json
{
  "title": "Report Title",
  "summary": "50-word summary...",
  "file_paths": ["/path/to/file1", "/path/to/file2"],
  "recommendations": ["Recommendation 1", "Recommendation 2"]
}
```

**Exit Codes**:
- `0`: Success
- `1`: Failure (file not found, invalid format)

##### `extract_plan_metadata(plan_path)`

Extract complexity, phases, time estimates from implementation plans.

**Arguments**:
- `plan_path` (string): Absolute path to plan file

**Returns**: JSON object with metadata:
```json
{
  "complexity": "7.5/10",
  "phases": 6,
  "estimated_duration": "6.5-7.5 hours",
  "dependencies": []
}
```

**Exit Codes**:
- `0`: Success
- `1`: Failure (file not found, invalid format)

##### `load_metadata_on_demand(artifact_path)`

Generic metadata loader with caching for reports, plans, or summaries.

**Arguments**:
- `artifact_path` (string): Absolute path to artifact file

**Returns**: JSON metadata (format depends on artifact type)

**Exit Codes**:
- `0`: Success
- `1`: Failure (file not found, unsupported type)

---

### checkpoint-utils.sh

Checkpoint-based state management for resumable workflows. Enables `/implement` to resume after failures.

**Performance**: <50ms checkpoint save/load

#### Core Functions

##### `save_checkpoint(checkpoint_name, state_data)`

Save workflow state to checkpoint file.

**Arguments**:
- `checkpoint_name` (string): Unique checkpoint identifier
- `state_data` (string): JSON state data

**Returns**: Nothing

**Exit Codes**:
- `0`: Success
- `1`: Failure (write failed)

##### `load_checkpoint(checkpoint_name)`

Load workflow state from checkpoint file.

**Arguments**:
- `checkpoint_name` (string): Unique checkpoint identifier

**Returns**: JSON state data (printed to stdout)

**Exit Codes**:
- `0`: Success
- `1`: Failure (checkpoint not found)

##### `list_checkpoints(pattern)`

List available checkpoints matching pattern.

**Arguments**:
- `pattern` (optional, string): Glob pattern to filter checkpoints

**Returns**: Newline-separated list of checkpoint names

**Exit Codes**: `0` (always succeeds)

---

### state-persistence.sh

GitHub Actions-style state persistence for selective file-based state management. Implements hybrid approach combining stateless recalculation for fast operations with file-based state for critical items.

**Pattern**: Selective state persistence (GitHub Actions `$GITHUB_OUTPUT` model)
**Performance**: 67% improvement (6ms init → 2ms load for CLAUDE_PROJECT_DIR)
**Test Coverage**: 18 tests, 100% pass rate
**Dependencies**: `jq` (JSON parsing), `mktemp` (atomic writes)

**When to Use**:
- State accumulates across subprocess boundaries
- Context reduction requires metadata aggregation (95% reduction)
- Success criteria validation needs objective evidence
- Resumability valuable for multi-hour workflows
- State is non-deterministic (research findings, user surveys)
- Recalculation is expensive (>30ms)
- Phase dependencies require prior phase outputs

**When NOT to Use**:
- Fast recalculation (<10ms and deterministic)
- State is ephemeral (temporary variables)
- No subprocess boundaries (single bash block)
- Canonical source exists elsewhere (library-api.md)
- File-based overhead exceeds recalculation cost

See [Selective State Persistence](./../architecture/coordinate-state-management.md#selective-state-persistence) for complete decision criteria and patterns.

#### Core Functions

##### `init_workflow_state(workflow_id)`

Initialize workflow state file with initial environment variables. Call once per workflow invocation (Block 1 only).

**Arguments**:
- `workflow_id` (string, optional): Unique identifier for workflow (default: `$$`)

**Returns**: Absolute path to created state file (printed to stdout)

**Side Effects**:
- Creates state file in `.claude/tmp/workflow_${workflow_id}.sh`
- Detects and caches CLAUDE_PROJECT_DIR (70% performance improvement)
- Exports CLAUDE_PROJECT_DIR, WORKFLOW_ID, STATE_FILE

**Performance**: ~6ms (includes git rev-parse)

**Exit Codes**:
- `0`: Success

**Usage**:
```bash
source "${CLAUDE_PROJECT_DIR}/.claude/lib/state-persistence.sh"
STATE_FILE=$(init_workflow_state "coordinate_$$")
trap "rm -f '$STATE_FILE'" EXIT  # Cleanup on exit
```

**Note**: Caller must set EXIT trap for cleanup (not set inside function to avoid subshell cleanup issues).

##### `load_workflow_state(workflow_id)`

Load workflow state file to restore exported variables. Call in subsequent bash blocks (Blocks 2+).

**Arguments**:
- `workflow_id` (string, optional): Unique identifier for workflow (default: `$$`)

**Returns**: Nothing (sources state file, exports variables)

**Side Effects**:
- Sources state file (exports all variables from init and appends)
- If missing, falls back to `init_workflow_state` (graceful degradation)

**Performance**: ~2ms (file read only)

**Exit Codes**:
- `0`: State file loaded successfully
- `1`: State file missing (fallback executed)

**Usage**:
```bash
source "${CLAUDE_PROJECT_DIR}/.claude/lib/state-persistence.sh"
load_workflow_state "coordinate_$$"
echo "$CLAUDE_PROJECT_DIR"  # Variable restored from state file
```

**Graceful Degradation**: If state file deleted mid-workflow, automatically recalculates (no crash).

##### `append_workflow_state(key, value)`

Append new key-value pair to workflow state file. Follows GitHub Actions `$GITHUB_OUTPUT` pattern.

**Arguments**:
- `key` (string): Variable name to export
- `value` (string): Variable value

**Returns**: Nothing

**Side Effects**:
- Appends `export KEY="value"` to state file
- Variable available in subsequent `load_workflow_state` calls

**Performance**: <1ms (simple echo redirect)

**Exit Codes**:
- `0`: Success
- `1`: Failure (STATE_FILE not set - call `init_workflow_state` first)

**Usage**:
```bash
append_workflow_state "RESEARCH_COMPLETE" "true"
append_workflow_state "REPORTS_CREATED" "4"
# Subsequent blocks see: RESEARCH_COMPLETE="true", REPORTS_CREATED="4"
```

##### `save_json_checkpoint(checkpoint_name, json_data)`

Save structured data as JSON checkpoint file with atomic write semantics.

**Arguments**:
- `checkpoint_name` (string): Name of checkpoint (without .json extension)
- `json_data` (string): JSON string to save

**Returns**: Nothing

**Side Effects**:
- Creates `.claude/tmp/${checkpoint_name}.json`
- Uses atomic write (temp file + mv) to prevent partial writes

**Performance**: 5-10ms (atomic write with temp file + mv + fsync)

**Exit Codes**:
- `0`: Success
- `1`: Failure (CLAUDE_PROJECT_DIR not set)

**Usage**:
```bash
SUPERVISOR_METADATA='{"topics": 4, "reports": ["r1.md", "r2.md"]}'
save_json_checkpoint "supervisor_metadata" "$SUPERVISOR_METADATA"
# File created: .claude/tmp/supervisor_metadata.json
```

**Atomicity Guarantee**: Uses temp file + mv to ensure no partial writes on crash.

##### `load_json_checkpoint(checkpoint_name)`

Load JSON checkpoint file created by `save_json_checkpoint`.

**Arguments**:
- `checkpoint_name` (string): Name of checkpoint (without .json extension)

**Returns**: JSON content if file exists, or `{}` if missing (printed to stdout)

**Performance**: 2-5ms (cat + optional jq validation)

**Exit Codes**:
- `0`: Success (file exists or graceful degradation)
- `1`: Failure (CLAUDE_PROJECT_DIR not set)

**Usage**:
```bash
METADATA=$(load_json_checkpoint "supervisor_metadata")
echo "$METADATA" | jq -r '.topics'
# Output: 4
```

**Graceful Degradation**: Returns empty JSON object `{}` if file missing (no error).

##### `append_jsonl_log(log_name, json_entry)`

Append JSON entry to JSONL (JSON Lines) log file. Each line is a complete JSON object.

**Arguments**:
- `log_name` (string): Name of log file (without .jsonl extension)
- `json_entry` (string): JSON object to append (single line)

**Returns**: Nothing

**Side Effects**:
- Appends JSON line to `.claude/tmp/${log_name}.jsonl`
- Creates file if it doesn't exist

**Performance**: <1ms (echo redirect)

**Exit Codes**:
- `0`: Success
- `1`: Failure (CLAUDE_PROJECT_DIR not set)

**Usage**:
```bash
BENCHMARK='{"phase": "research", "duration_ms": 12500, "timestamp": "2025-11-07T14:30:00Z"}'
append_jsonl_log "benchmarks" "$BENCHMARK"
# File contains newline-separated JSON objects:
# {"phase": "research", "duration_ms": 12500, "timestamp": "2025-11-07T14:30:00Z"}
# {"phase": "plan", "duration_ms": 8500, "timestamp": "2025-11-07T14:32:00Z"}
```

**Use Cases**:
- Benchmark dataset accumulation across subprocess invocations
- Performance metrics logging (timestamped phase durations)
- POC metrics tracking (success criterion validation)

#### Complete Workflow Example

```bash
# Block 1: Initialize workflow state
source "${CLAUDE_PROJECT_DIR}/.claude/lib/state-persistence.sh"
STATE_FILE=$(init_workflow_state "coordinate_$$")
trap "rm -f '$STATE_FILE'" EXIT

# CLAUDE_PROJECT_DIR detected once and cached (6ms)

# Block 2: Research phase
source "${CLAUDE_PROJECT_DIR}/.claude/lib/state-persistence.sh"
load_workflow_state "coordinate_$$"  # Fast load (2ms)

# Invoke research supervisor (returns aggregated metadata)
SUPERVISOR_RESULT='{"topics": 4, "reports": ["r1.md", "r2.md"], "summary": "..."}'
save_json_checkpoint "supervisor_metadata" "$SUPERVISOR_RESULT"
append_workflow_state "RESEARCH_COMPLETE" "true"

# Block 3: Plan phase
source "${CLAUDE_PROJECT_DIR}/.claude/lib/state-persistence.sh"
load_workflow_state "coordinate_$$"

# Load research metadata (95% context reduction vs full outputs)
METADATA=$(load_json_checkpoint "supervisor_metadata")
REPORTS=$(echo "$METADATA" | jq -r '.reports[]')

# Log phase benchmark
BENCHMARK='{"phase": "research", "duration_ms": 12500, "context_tokens": 1000}'
append_jsonl_log "workflow_benchmarks" "$BENCHMARK"

# Check accumulated state
echo "Research complete: ${RESEARCH_COMPLETE}"  # Output: true
```

#### Decision Criteria Reference

**Use File-Based State When**:
1. Recalculation cost >30ms (measured performance improvement)
2. State is non-deterministic (research findings, user input)
3. State accumulates across subprocess boundaries (Phase 3 benchmarks)
4. Context reduction requires metadata aggregation (supervisor outputs)
5. Cross-invocation persistence needed (resumable workflows)
6. Phase dependencies require prior outputs (Phase 3 depends on Phase 2)
7. Success criteria validation needs evidence (timestamped metrics)

**Use Stateless Recalculation When**:
1. Recalculation is fast (<10ms) and deterministic
2. State is ephemeral (temporary variables)
3. No subprocess boundaries (single bash block)
4. Canonical source exists elsewhere (library-api.md)
5. File-based overhead exceeds recalculation cost

**Critical State Items** (7/10 analyzed items use file-based state):
- Supervisor metadata (95% context reduction)
- Benchmark datasets (accumulation across 10 invocations)
- Implementation supervisor state (40-60% time savings tracking)
- Testing supervisor state (lifecycle coordination)
- Migration progress (resumable, audit trail)
- Performance benchmarks (phase dependencies)
- POC metrics (timestamped validation)

**Performance Comparison**:
- `init_workflow_state`: 6ms (includes git rev-parse)
- `load_workflow_state`: 2ms (file read) = **67% faster than init**
- `save_json_checkpoint`: 5-10ms (atomic write)
- `load_json_checkpoint`: 2-5ms (cat + validation)
- `append_workflow_state`: <1ms (echo)
- `append_jsonl_log`: <1ms (echo)

---

## Workflow Classification

### workflow-llm-classifier.sh

LLM-based semantic workflow classification using Claude Haiku 4.5 for high-accuracy intent detection. Returns enhanced topics with detailed descriptions, filename slugs, and research focus areas.

**Pattern**: Semantic understanding with confidence thresholds
**Accuracy**: 98%+ (vs 92% regex-only)
**Cost**: $0.03/month for typical usage (100 classifications/day)
**Test Coverage**: 37 tests, 100% pass rate (35 passing, 2 skipped for manual integration)
**Dependencies**: `jq` (JSON parsing), AI assistant file-based signaling

**When to Use**:
- Semantic ambiguity in user input (e.g., "research the implement command" vs "implement feature")
- Keyword context confusion (discussing vs requesting workflow types)
- Negation handling (e.g., "don't revise the plan")
- Edge cases expensive to handle with regex patterns

**When NOT to Use**:
- Structured data parsing (file paths, explicit flags)
- Performance-critical hot paths (<1ms required)
- Deterministic classification sufficient
- Offline/air-gapped environments

#### Core Functions

##### `classify_workflow_llm(workflow_description)`

Invoke LLM classifier with timeout and confidence validation.

**Parameters**:
- `workflow_description` (string): User workflow description to classify

**Returns**: JSON object with `scope`, `confidence`, `reasoning` fields (or exits with code 1 for fallback)

**Exit Codes**:
- `0`: Classification successful (confidence >= threshold)
- `1`: Classification failed or low confidence (triggers fallback)

**Example**:
```bash
source .claude/lib/workflow-llm-classifier.sh

# Semantic edge case (LLM handles better than regex)
result=$(classify_workflow_llm "research the research-and-revise workflow")
scope=$(echo "$result" | jq -r '.scope')  # Expected: "research-only"
confidence=$(echo "$result" | jq -r '.confidence')  # e.g., 0.95
```

##### `build_llm_classifier_input(workflow_description)`

Build JSON prompt for LLM classification request.

**Parameters**:
- `workflow_description` (string): Workflow description

**Returns**: JSON string for LLM request

##### `invoke_llm_classifier(llm_input)`

Invoke AI assistant via file-based signaling with timeout.

**Parameters**:
- `llm_input` (string): JSON classification request

**Returns**: LLM response JSON (or exits with code 1 on timeout)

**Timeout**: Configurable via `WORKFLOW_CLASSIFICATION_TIMEOUT` (default: 10 seconds)

##### `parse_llm_classifier_response(response)`

Validate LLM response and check confidence threshold.

**Parameters**:
- `response` (string): LLM response JSON

**Returns**: Validated response (or exits with code 1 if confidence < threshold)

**Confidence Threshold**: Configurable via `WORKFLOW_CLASSIFICATION_CONFIDENCE_THRESHOLD` (default: 0.7)

---

### workflow-scope-detection.sh

Unified workflow classification with 2-mode system: llm-only (default, online) and regex-only (offline). LLM-only mode uses fail-fast error handling, no automatic fallback.

**Pattern**: 2-mode classification with fail-fast error handling
**Modes**: llm-only (default, online), regex-only (offline)
**Accuracy**: 98%+ (llm-only), 92% (regex-only)
**Reliability**: 95-98% (llm-only), 100% (regex-only)
**Test Coverage**: 33 tests, 90.9% pass rate (30 passing, 1 failure, 2 skipped)
**Dependencies**: `workflow-llm-classifier.sh` (llm-only mode), `jq` (JSON parsing)

**BREAKING CHANGE**: Hybrid mode removed in Spec 688 clean-break update. Use `llm-only` (default) or `regex-only` (offline) explicitly.

**Backward Compatibility**: 100% compatible with existing code (function signature unchanged)

#### Core Functions

##### `detect_workflow_scope(workflow_description)`

Unified workflow classification with automatic mode detection and fallback.

**Parameters**:
- `workflow_description` (string): Workflow description to classify

**Returns**: Scope string (`research-only`, `research-and-plan`, `research-and-revise`, `full-implementation`, `debug-only`)

**Exit Codes**: `0` (always succeeds - fallback ensures reliability)

**Modes** (controlled by `WORKFLOW_CLASSIFICATION_MODE` environment variable):
- `llm-only` (default): LLM classification with fail-fast on errors
- `regex-only`: Traditional regex patterns for offline/testing

**BREAKING**: `hybrid` mode removed - no automatic fallback

**Example**:
```bash
source .claude/lib/workflow-scope-detection.sh

# llm-only mode (default) - Use classify_workflow_comprehensive
result=$(classify_workflow_comprehensive "research auth patterns and create plan")
scope=$(echo "$result" | jq -r '.workflow_type')
echo "$scope"  # Output: "research-and-plan"

# Backward compatibility wrapper
scope=$(detect_workflow_scope "research auth patterns")
echo "$scope"  # Output: "research-and-plan"

# Regex-only mode for offline
WORKFLOW_CLASSIFICATION_MODE=regex-only \
  scope=$(detect_workflow_scope "implement feature X")
echo "$scope"  # Output: "full-implementation"

# Error handling for LLM failures
if ! result=$(classify_workflow_comprehensive "task" 2>&1); then
  echo "LLM failed, using regex-only..." >&2
  WORKFLOW_CLASSIFICATION_MODE=regex-only \
    result=$(classify_workflow_comprehensive "task")
fi
```

##### `classify_workflow_regex(workflow_description)`

Traditional regex-based classification (embedded fallback logic).

**Parameters**:
- `workflow_description` (string): Workflow description

**Returns**: Scope string (same as `detect_workflow_scope`)

**Pattern Priorities** (ordered by specificity):
1. Research-and-revise patterns (revision-first, explicit revise keywords)
2. Plan path detection (specs/NNN_topic/plans/*.md)
3. Explicit keyword patterns (implement, execute)
4. Research-only pattern (pure research, no action keywords)
5. Other patterns (plan, debug, build)

---

## Agent Support

### agent-registry-utils.sh

Agent registration and discovery. Used by `/orchestrate` and Task tool integration.

#### Core Functions

##### `register_agent(agent_name, agent_path, capabilities)`

Register an agent in the global registry.

**Arguments**:
- `agent_name` (string): Unique agent identifier
- `agent_path` (string): Absolute path to agent definition
- `capabilities` (string): Comma-separated capability list

**Returns**: Nothing

**Exit Codes**:
- `0`: Success
- `1`: Failure (invalid arguments, registry write failed)

##### `discover_agent(capability_pattern)`

Discover registered agents matching capability pattern.

**Arguments**:
- `capability_pattern` (string): Regex pattern to match capabilities

**Returns**: Newline-separated list of matching agent paths

**Exit Codes**: `0` (always succeeds)

---

### hierarchical-agent-support.sh

Multi-level agent coordination for recursive supervision patterns.

#### Core Functions

##### `invoke_subagent(agent_name, task_description, context_metadata)`

Invoke a subagent with metadata context (not full content).

**Arguments**:
- `agent_name` (string): Agent identifier
- `task_description` (string): Task for subagent
- `context_metadata` (string): JSON metadata from parent agent

**Returns**: JSON response from subagent

**Exit Codes**:
- `0`: Success
- `1`: Failure (agent not found, invocation failed)

---

## Workflow Support

### unified-logger.sh

Structured logging with automatic rotation. Used by `/implement`, `/orchestrate`, adaptive planning.

**Log Location**: `.claude/data/logs/`

**Rotation**: 10MB max per log, 5 files retained

#### Core Functions

##### `log_info(message, [context])`

Log informational message with optional JSON context.

**Arguments**:
- `message` (string): Log message
- `context` (optional, string): JSON context object

**Returns**: Nothing (writes to log file)

**Exit Codes**: `0` (always succeeds)

##### `log_error(message, [context])`

Log error message with optional JSON context.

**Arguments**:
- `message` (string): Error message
- `context` (optional, string): JSON context object

**Returns**: Nothing (writes to log file and stderr)

**Exit Codes**: `0` (always succeeds)

##### `query_logs(pattern, [time_range])`

Query log files by pattern and optional time range.

**Arguments**:
- `pattern` (string): Grep-compatible search pattern
- `time_range` (optional, string): ISO 8601 time range (e.g., "2025-10-20T00:00:00/2025-10-23T23:59:59")

**Returns**: Matching log entries (newline-separated)

**Exit Codes**: `0` (always succeeds)

---

### error-handling.sh

Standardized error handling patterns for commands.

#### Core Functions

##### `handle_error(error_code, error_message, [recovery_action])`

Handle errors with optional recovery action.

**Arguments**:
- `error_code` (integer): Numeric error code
- `error_message` (string): Human-readable error description
- `recovery_action` (optional, string): Recovery command to execute

**Returns**: Nothing (exits script with error_code)

**Exit Codes**: Exits with `error_code`

---

### context-pruning.sh

Context window optimization through aggressive metadata pruning.

**Target**: <30% context usage throughout workflows

**Achieved**: 92-97% reduction through metadata-only passing

#### Core Functions

##### `prune_subagent_output(output_text)`

Clear full subagent output after metadata extraction.

**Arguments**:
- `output_text` (string): Full subagent output

**Returns**: Nothing (clears output from context)

**Exit Codes**: `0` (always succeeds)

##### `prune_phase_metadata(phase_number)`

Remove completed phase data from context.

**Arguments**:
- `phase_number` (integer): Phase to prune

**Returns**: Nothing

**Exit Codes**: `0` (always succeeds)

##### `apply_pruning_policy(workflow_type)`

Apply automatic pruning by workflow type.

**Arguments**:
- `workflow_type` (string): Workflow type (e.g., "implement", "orchestrate", "research")

**Returns**: Nothing

**Exit Codes**: `0` (always succeeds)

---

### overview-synthesis.sh

Standardized overview synthesis decision logic for orchestration commands.

**Purpose**: Provides uniform decision logic for when OVERVIEW.md synthesis should occur across `/research`, `/supervise`, and `/coordinate` commands.

**Commands using this library**: `/research`, `/supervise`, `/coordinate`

**Key Principle**: Overview synthesis only occurs when workflows conclude with research (no planning follows). When planning phase follows research, the plan-architect agent synthesizes reports, making OVERVIEW.md redundant.

#### Core Functions

##### `should_synthesize_overview(workflow_scope, report_count)`

Determines if overview synthesis should occur based on workflow scope and report count.

**Arguments**:
- `workflow_scope` (string): Workflow type (research-only | research-and-plan | full-implementation | debug-only)
- `report_count` (integer): Number of successful research reports created

**Returns**: Nothing (uses exit code to indicate decision)

**Exit Codes**:
- `0` (true): Overview should be synthesized
- `1` (false): Overview should NOT be synthesized

**Decision Logic**:
- Requires ≥2 reports for synthesis (can't synthesize 1 report into overview)
- `research-only`: Returns `0` (workflow ends with research)
- `research-and-plan`: Returns `1` (plan-architect will synthesize)
- `full-implementation`: Returns `1` (plan-architect will synthesize)
- `debug-only`: Returns `1` (debug doesn't produce research reports)
- Unknown scope: Returns `1` (conservative default)

**Usage Example**:
```bash
# /research is always research-only workflow
WORKFLOW_SCOPE="research-only"

if should_synthesize_overview "$WORKFLOW_SCOPE" "$REPORT_COUNT"; then
  # Create OVERVIEW.md
  OVERVIEW_PATH=$(calculate_overview_path "$RESEARCH_SUBDIR")
  echo "Creating overview at: $OVERVIEW_PATH"
else
  # Skip synthesis - plan will synthesize reports
  SKIP_REASON=$(get_synthesis_skip_reason "$WORKFLOW_SCOPE" "$REPORT_COUNT")
  echo "Skipping overview: $SKIP_REASON"
fi
```

##### `calculate_overview_path(research_subdir)`

Calculates the standardized path for OVERVIEW.md synthesis report.

**Arguments**:
- `research_subdir` (string): Directory containing research reports (e.g., `specs/042_auth/reports/001_auth_research`)

**Returns**: Prints standardized overview path to stdout

**Exit Codes**:
- `0`: Success
- `1`: Error (empty research_subdir argument)

**Path Format**: `${research_subdir}/OVERVIEW.md`

**Rationale**: ALL CAPS distinguishes synthesis from numbered subtopic reports, consistent with industry convention (README, LICENSE, OVERVIEW).

**Usage Example**:
```bash
RESEARCH_SUBDIR="${TOPIC_PATH}/reports"
OVERVIEW_PATH=$(calculate_overview_path "$RESEARCH_SUBDIR")
# Result: /path/to/specs/042_topic/reports/OVERVIEW.md
```

##### `get_synthesis_skip_reason(workflow_scope, report_count)`

Returns human-readable explanation of why overview synthesis was skipped.

**Arguments**:
- `workflow_scope` (string): Workflow type
- `report_count` (integer): Number of successful research reports

**Returns**: Prints skip reason to stdout

**Exit Codes**: `0` (always succeeds)

**Usage Example**:
```bash
if ! should_synthesize_overview "$WORKFLOW_SCOPE" "$REPORT_COUNT"; then
  REASON=$(get_synthesis_skip_reason "$WORKFLOW_SCOPE" "$REPORT_COUNT")
  echo "⏭️  Skipping overview synthesis"
  echo "  Reason: $REASON"
fi
```

**Skip Reasons**:
- Insufficient reports: "Insufficient reports for synthesis (need ≥2, have N)"
- research-and-plan/full-implementation: "Reports will be synthesized by plan-architect in Phase 2 (Planning)"
- debug-only: "Debug workflow does not produce research reports requiring synthesis"
- Unknown scope: "Unknown workflow scope: <scope> (defaulting to no synthesis)"

---

## Analysis and Validation

### complexity-thresholds.sh

Complexity scoring for plans. Used by `/plan` and adaptive planning in `/implement`.

#### Core Functions

##### `calculate_complexity(plan_path)`

Calculate complexity score for plan (0-10 scale).

**Arguments**:
- `plan_path` (string): Absolute path to plan file

**Returns**: Complexity score (float, e.g., "7.5")

**Factors**:
- Number of phases
- Tasks per phase
- File references per phase
- Dependency graph complexity

**Exit Codes**:
- `0`: Success
- `1`: Failure (file not found, invalid format)

---

### structure-validator.sh

Directory structure validation for topic directories.

#### Core Functions

##### `validate_topic_structure(topic_path)`

Validate that topic directory has all 6 required subdirectories.

**Arguments**:
- `topic_path` (string): Absolute path to topic directory

**Returns**: Validation report (JSON)

**Exit Codes**:
- `0`: Valid structure
- `1`: Invalid structure (missing subdirectories)

---

## Complete Library List

### Workflow Orchestration
- `unified-location-detection.sh` - Standardized location detection
- `parallel-orchestration-utils.sh` - Parallel subagent execution
- `workflow-detection.sh` - Workflow type detection from descriptions

### Plan Management
- `plan-core-bundle.sh` - Plan parsing and manipulation
- `progressive-planning-utils.sh` - Progressive plan expansion/collapse
- `complexity-thresholds.sh` - Plan complexity scoring
- `dependency-analyzer.sh` - Phase dependency analysis
- `checkpoint-utils.sh` - Checkpoint state management
- `checkbox-utils.sh` - Checkbox state tracking in plans

### Agent Coordination
- `agent-registry-utils.sh` - Agent registration and discovery
- `agent-discovery.sh` - Agent capability matching
- `agent-loading-utils.sh` - Agent definition loading
- `hierarchical-agent-support.sh` - Multi-level agent coordination
- `agent-frontmatter-validator.sh` - Agent metadata validation
- `agent-schema-validator.sh` - Agent schema validation

### Context Optimization
- `metadata-extraction.sh` - Report/plan metadata extraction
- `context-pruning.sh` - Context window optimization
- `context-metrics.sh` - Context usage measurement

### Artifact Management
- `artifact-creation.sh` - Artifact file creation
- `artifact-registry.sh` - Artifact tracking and cross-reference
- `artifact-cross-reference.sh` - Cross-reference resolution
- `artifact-cleanup.sh` - Artifact lifecycle management

### Logging and Monitoring
- `unified-logger.sh` - Structured logging with rotation
- `progress-tracker.sh` - Workflow progress tracking
- `progress-dashboard.sh` - Progress visualization
- `analyze-metrics.sh` - Performance metrics analysis

### Error Handling
- `error-handling.sh` - Standardized error handling
- `validation-utils.sh` - Input validation utilities

### Template and Substitution
- `template-integration.sh` - Template rendering
- `parse-template.sh` - Template parsing
- `substitute-variables.sh` - Variable substitution

### Testing and Validation
- `detect-testing.sh` - Test infrastructure detection
- `generate-testing-protocols.sh` - Test protocol generation
- `structure-validator.sh` - Directory structure validation

### Git Integration
- `git-utils.sh` - Git operations (commit, push, status)

### Conversion Utilities
- `convert-core.sh` - Document format conversion
- `convert-docx.sh` - DOCX conversion
- `convert-markdown.sh` - Markdown conversion
- `convert-pdf.sh` - PDF conversion

### Miscellaneous
- `json-utils.sh` - JSON parsing and manipulation
- `timestamp-utils.sh` - Timestamp utilities
- `base-utils.sh` - Base utility functions
- `deps-utils.sh` - Dependency checking

### Migration Scripts
- `migrate-checkpoint-v1.3.sh` - Checkpoint migration
- `migrate-agent-registry.sh` - Agent registry migration

---

## Usage Notes

### Sourcing Libraries

Always source libraries using absolute paths from `CLAUDE_CONFIG`:

```bash
# Recommended
source "${CLAUDE_CONFIG}/.claude/lib/unified-location-detection.sh"

# Also acceptable (relative path from .claude/)
source "$(dirname "${BASH_SOURCE[0]}")/../lib/unified-location-detection.sh"
```

### jq Dependency

Many libraries support optional jq for JSON parsing:

```bash
# Preferred (jq available)
if command -v jq &>/dev/null; then
  TOPIC_PATH=$(echo "$JSON" | jq -r '.topic_path')
else
  # Fallback (sed/grep parsing)
  TOPIC_PATH=$(echo "$JSON" | grep -o '"topic_path": *"[^"]*"' | sed 's/.*: *"\([^"]*\)".*/\1/')
fi
```

### Error Handling

All libraries follow consistent error handling:

```bash
# Check exit code
if ! perform_location_detection "description"; then
  echo "ERROR: Location detection failed"
  exit 1
fi

# Or use command substitution with || operator
RESULT=$(some_library_function "arg") || {
  echo "ERROR: Function failed"
  exit 1
}
```

### Performance Characteristics

| Library | Typical Execution Time | Token Usage | Notes |
|---------|----------------------|-------------|-------|
| unified-location-detection.sh | <1s | <11k | No AI calls |
| plan-core-bundle.sh | <1s | 0 | Pure bash |
| metadata-extraction.sh | <100ms | 0 | Pure bash |
| checkpoint-utils.sh | <50ms | 0 | File I/O only |
| agent-registry-utils.sh | <100ms | 0 | File I/O only |
| unified-logger.sh | <10ms | 0 | Append-only writes |

---

## See Also

- [Using Utility Libraries](../guides/using-utility-libraries.md) - Task-focused guide for library usage
- [Command Development Guide](../guides/command-development-guide.md) - Creating commands that use libraries
- [Agent Development Guide](../guides/agent-development-guide.md) - Creating agents that use libraries
- [Performance Measurement](../guides/performance-optimization.md) - Measuring library performance impact
